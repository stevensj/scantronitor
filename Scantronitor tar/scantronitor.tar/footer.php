<p align="center" class=footer><font size=1>Your company footer goes here</font></p>
