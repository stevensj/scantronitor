<?
  # ===========================================================
  # file name:  past/header.php
  # purpose:    header for each .php page
  # created:    June 2011
  # authors:    Don Franke
  #             Josh Stevens
  #             Peter Babcock
  # ===========================================================
?>
  
<table width="100%" class="header">
	<tr>
		<td align="left" valign="middle"><a href=../index.php><img
			src="../images/scantronitor.png"
			alt="Scantronitor" border="0" vspace="5"></a>
		</td>
	</tr>
</table>
<table id="linkbox" cellspacing="0">
	<tr>
		<td class="flank">&nbsp; </td>
		<td width="200" class="link"><a href=../>Home</a></td>
		<td width="200" class="highlight">Past</td>
		<td width="200" class="link"><a href=../present>Present</a></td>
		<td width="200" class="link"><a href=../future>Future</a></td>
		<td class="flank">&nbsp; </td>
	</tr>
</table>

